import sys
from kiwipiepy import Kiwi
from sentence_transformers import SentenceTransformer, util
import pymysql
import re
import torch
from collections import defaultdict

# 모델 및 형태소 분석기 초기화
model = SentenceTransformer("snunlp/KR-SBERT-V40K-klueNLI-augSTS")
kiwi = Kiwi()

# DB 연결
try:
    conn = pymysql.connect(
        host='10.50.131.18',
        port=3306,
        user='user',
        password='user1234',
        database='maildb',
        charset='utf8'
    )
    cursor = conn.cursor()

except pymysql.Error as e:
    print(f"DB 연결 오류: {e}")
    sys.exit(1)

# 키워드 테이블 목록 (카테고리 목록)
keyword_tables = ['finance_keywords', 'government_keywords', 'portal_keywords', 'advertisement_keywords']


# 명사만 추출 (NNG: 일반 명사, NNP: 고유 명사)
def extract_keywords(text):
    tokens = kiwi.tokenize(text)
    return [token.form for token in tokens if token.tag in ("NNG", "NNP") and token.form.isalpha()]


def get_keywords_from_table(table_name):
    cursor.execute(f"SELECT word FROM {table_name}")
    return [row[0] for row in cursor.fetchall()]


# 분류 결과를 mail_info 테이블의 categori 컬럼에 업데이트하는 함수
# user_id와 mailNum을 함께 사용하여 특정 레코드를 식별합니다.
def update_mail_category(user_id, mail_num, category_result):
    try:
        cursor.execute(
            f"UPDATE mail_info SET categori = %s WHERE user_id = %s AND mailnum = %s",
            (category_result, user_id, mail_num)
        )
        conn.commit()
        return True
    except pymysql.Error as e:
        print(f"DB 업데이트 오류 (UserID: {user_id}, MailNum: {mail_num}, Category: {category_result}): {e}")
        conn.rollback()
        return False


if __name__ == "__main__":
    # 명령줄 인자로부터 target_user_id (분류할 사용자 ID) 받기
    if len(sys.argv) < 2:
        print("사용법: python mail_classifier_advanced.py <target_user_id>")
        print("예시: python mail_classifier_advanced.py user123")
        sys.exit(1)

    target_user_id = sys.argv[1]  # 스크립트 실행 시 첫 번째 인자로 받을 user_id
    print(f"--- User '{target_user_id}'의 메일을 분류하여 DB에 업데이트합니다 ---")

    # 모든 키워드 테이블의 키워드를 미리 로드 및 임베딩 (효율성을 위해)
    all_table_keywords = {}
    all_keyword_embeddings = {}

    for table_name in keyword_tables:
        keywords = get_keywords_from_table(table_name)
        all_table_keywords[table_name] = keywords
        if keywords:
            all_keyword_embeddings[table_name] = model.encode(keywords, convert_to_tensor=True)
        else:
            all_keyword_embeddings[table_name] = torch.tensor([])

    # 특정 user_id의 메일 제목, user_id, mailNum을 전부 가져오기
    try:
        # user_id와 mailNum 컬럼도 함께 가져오도록 쿼리 수정
        cursor.execute("SELECT user_id, mailnum, title FROM mail_info WHERE user_id = %s", (target_user_id,))
        mails_to_process = cursor.fetchall()  # (user_id, mailNum, title) 튜플 리스트
    except pymysql.Error as e:
        print(f"메일 조회 오류: {e}")
        conn.close()
        sys.exit(1)

    if not mails_to_process:
        print(f"사용자 '{target_user_id}'의 메일이 없습니다.")
        conn.close()
        sys.exit(0)

    # 분류 관련 임계치
    TOP_K_KEYWORDS = 100  # 가장 유사도가 높은 상위 K개 키워드 사용
    MIN_SIMILARITY_FOR_CANDIDATE = 0.35  # 상위 K개 후보에 들기 위한 최소 유사도
    FINAL_CLASSIFICATION_THRESHOLD = 0.6  # 최종 분류로 인정하기 위한 최소 유사도 (이 미만이면 Unclassified)

    # --- 메인 분류 및 DB 업데이트 루프 ---
    for mail_idx, (user_id, mailnum, title) in enumerate(mails_to_process):
        print(
            f"\n--- {mail_idx + 1}/{len(mails_to_process)} Processing Mail (UserID: {user_id}, MailNum: {mailnum}) ---")
        display_title = title if len(title) < 70 else title[:67] + "..."
        print(f"  Mail Title: '{display_title}'")

        tokens = extract_keywords(title)
        if not tokens:
            classified_category = "Unclassified (No_Keywords)"
            print(f"No valid nouns found in this mail title. Classifying as: {classified_category}")
            if update_mail_category(user_id, mailnum, classified_category):  # user_id 전달
                print(f"UserID {user_id}, MailNum {mailnum} updated to '{classified_category}'.")
            continue

        title_token_embeddings = model.encode(tokens, convert_to_tensor=True)

        all_similarities = []

        # 메일 제목의 각 토큰과 모든 카테고리 키워드 간의 유사도 계산
        for table_name in keyword_tables:
            keywords_in_table = all_table_keywords[table_name]
            embeddings_in_table = all_keyword_embeddings[table_name]

            if not embeddings_in_table.numel():
                continue

            similarity_matrix = util.pytorch_cos_sim(title_token_embeddings, embeddings_in_table)

            for i, title_token in enumerate(tokens):
                for j, keyword_in_table in enumerate(keywords_in_table):
                    sim_score = similarity_matrix[i][j].item()
                    if sim_score >= MIN_SIMILARITY_FOR_CANDIDATE:
                        all_similarities.append({
                            'title_token': title_token,
                            'keyword_in_table': keyword_in_table,
                            'similarity': sim_score,
                            'table_name': table_name
                        })

        # 유사도 기준으로 내림차순 정렬하고 상위 K개 선택
        all_similarities.sort(key=lambda x: x['similarity'], reverse=True)
        top_k_similarities = all_similarities[:TOP_K_KEYWORDS]

        if not top_k_similarities:
            classified_category = "Unclassified (No_High_Sim_Keywords)"
            print(
                f"No keywords with similarity >= {MIN_SIMILARITY_FOR_CANDIDATE:.2f} found. Classifying as: {classified_category}")
            if update_mail_category(user_id, mailnum, classified_category):  # user_id 전달
                print(f"UserID {user_id}, MailNum {mailnum} updated to '{classified_category}'.")
            continue

        # 카테고리별 득표수 및 평균 유사도 집계
        category_votes = defaultdict(int)
        category_sim_sums = defaultdict(float)
        category_sim_counts = defaultdict(int)

        max_overall_similarity = 0.0  # 상위 100개 중 가장 높은 유사도 추적

        for item in top_k_similarities:
            category_votes[item['table_name']] += 1
            category_sim_sums[item['table_name']] += item['similarity']
            category_sim_counts[item['table_name']] += 1
            if item['similarity'] > max_overall_similarity:
                max_overall_similarity = item['similarity']

        # 가장 많은 득표수를 얻은 카테고리 찾기
        if not category_votes:
            classified_category = "Unclassified (No_Top_K_Keywords)"
            print(f"No keywords found for top {TOP_K_KEYWORDS}. Classifying as: {classified_category}")
            if update_mail_category(user_id, mailnum, classified_category):  # user_id 전달
                print(f"UserID {user_id}, MailNum {mailnum} updated to '{classified_category}'.")
            continue

        max_votes = 0
        for cat, votes in category_votes.items():
            if votes > max_votes:
                max_votes = votes

        candidate_categories = [cat for cat, votes in category_votes.items() if votes == max_votes]

        # 득표수가 동일한 경우, 해당 카테고리들의 평균 유사도를 비교하여 최종 선택
        if len(candidate_categories) > 1:
            best_candidate_category = candidate_categories[0]
            highest_avg_sim_among_candidates = category_sim_sums[best_candidate_category] / category_sim_counts[
                best_candidate_category]

            for i in range(1, len(candidate_categories)):
                cat = candidate_categories[i]
                current_avg_sim = category_sim_sums[cat] / category_sim_counts[cat]
                if current_avg_sim > highest_avg_sim_among_candidates:
                    highest_avg_sim_among_candidates = current_avg_sim
                    best_candidate_category = cat
            classified_category = best_candidate_category
        else:
            classified_category = candidate_categories[0]

        # 최종 분류 임계치 확인 (가장 높은 키워드 유사도 기준)
        if max_overall_similarity >= FINAL_CLASSIFICATION_THRESHOLD:
            print(
                f"  Classification Result: {classified_category} (Max Sim in Top {TOP_K_KEYWORDS}: {max_overall_similarity:.2f})")
        else:
            classified_category = "Unclassified" + f" (Low_Max_Sim:{max_overall_similarity:.2f})"
            print(
                f"  Classification Result: {classified_category} (Max Sim in Top {TOP_K_KEYWORDS} is below {FINAL_CLASSIFICATION_THRESHOLD:.2f})")

        # DB 업데이트
        if update_mail_category(user_id, mailnum, classified_category):  # user_id 전달
            print(f"UserID {user_id}, MailNum {mailnum} updated to '{classified_category}'.")
        else:
            print(f"  Failed to update UserID {user_id}, MailNum {mailnum}.")

# --- DB 연결 종료 ---
cursor.close()
conn.close()
print(f"\n--- User '{target_user_id}'의 메일 분류 및 DB 업데이트 완료 ---")