사용법: python mail_classifier_advanced.py <target_user_id>
예시: python mail_classifier_advanced.py user123